package org.bukkit.block;

import org.bukkit.Nameable;

/**
 * Represents an enchanting table.
 */
public interface EnchantingTable extends BlockState, Nameable { }
