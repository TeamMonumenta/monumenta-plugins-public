package org.bukkit.block;

/**
 * Represents an ender chest.
 */
public interface EnderChest extends BlockState { }
