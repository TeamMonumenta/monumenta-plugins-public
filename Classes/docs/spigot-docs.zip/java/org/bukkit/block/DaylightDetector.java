package org.bukkit.block;

/**
 * Represents a (possibly inverted) daylight detector.
 */
public interface DaylightDetector extends BlockState { }
