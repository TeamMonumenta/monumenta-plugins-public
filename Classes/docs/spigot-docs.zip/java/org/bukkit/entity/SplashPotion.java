package org.bukkit.entity;

/**
 * Represents a thrown splash potion bottle
 */
public interface SplashPotion extends ThrownPotion { }
