package org.bukkit.entity;

/**
 * Represents a Vex.
 */
public interface Vex extends Monster { }
