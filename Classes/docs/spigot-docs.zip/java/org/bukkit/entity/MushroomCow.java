package org.bukkit.entity;

/**
 * Represents a mushroom {@link Cow}
 */
public interface MushroomCow extends Cow {

}
