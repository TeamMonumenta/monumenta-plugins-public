package org.bukkit.entity;

public interface Endermite extends Monster {
}
