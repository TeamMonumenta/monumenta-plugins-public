package org.bukkit.entity;

/**
 * Represents a Vindicator.
 */
public interface Vindicator extends Monster { }
