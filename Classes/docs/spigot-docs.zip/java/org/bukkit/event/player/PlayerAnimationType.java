package org.bukkit.event.player;

/**
 * Different types of player animations
 */
public enum PlayerAnimationType {
    ARM_SWING
}
